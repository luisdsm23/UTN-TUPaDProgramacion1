# 🌍 Sistema de Gestión de Países - Presentación y Defensa TPI
**Cátedra:** Programación 1  
**Carrera:** Tecnicatura Universitaria en Programación a Distancia  
**Institución:** Universidad Tecnológica Nacional (UTN)  

---

## 🚀 Inicio Rápido de la Aplicación

Para iniciar el sistema y comenzar la presentación o defensa:

### En Windows (1 Clic):
Hacer doble clic en el archivo:
```text
INICIAR_APP.bat
```
*(Esto levantará automáticamente el servidor en Python nativo y abrirá la aplicación en tu navegador web predeterminado en `http://localhost:8000`)*.

### Desde la Terminal / Consola:
```bash
python app_web.py
```

---

## 📚 Documentos Clave para la Defensa

1. **[GUIA_DEFENSA.md](GUIA_DEFENSA.md):** Guion estratégico paso a paso de 5 minutos para exponer frente al profesor, con respuestas preparadas a las preguntas teóricas y técnicas más frecuentes.
2. **[Documentacion_TPI.pdf](Documentacion_TPI.pdf):** Documento formal académico y técnico del proyecto con carátula, marco teórico, diseño y conclusiones.
3. **[test_tpi.py](test_tpi.py):** Suite de 14 pruebas unitarias automatizadas para demostrar la confiabilidad y calidad del código.

---

## 🛠️ Tecnologías y Arquitectura

* **Backend:** Python 3 puro utilizando exclusivamente la **biblioteca estándar** (`http.server`, `socketserver`, `json`, `csv`, `unicodedata`, `urllib.parse`).
* **Frontend:** Single Page Application (SPA) responsiva con HTML5 semántico, CSS3 moderno (con temas Claro / Oscuro) y JavaScript Vanilla (ES6+).
* **Persistencia:** Archivos CSV en la carpeta `datos/` (`paises.csv` y `paises_mundo_completo.csv`).
* **Algoritmo de Ordenamiento:** Bubble Sort (Burbuja) implementado de forma algorítmica desde cero con bandera de optimización anticipada, con soporte **Ascendente** y **Descendente** por Nombre, Población, Superficie y Continente.
* **Validaciones del Backend:** Capa defensiva en `modulos/validaciones.py` que previene campos vacíos, tipos erróneos, valores negativos, continentes inexistentes, rangos inválidos y duplicados.

---

## 🧪 Ejecución de Pruebas Unitarias

Para demostrar el funcionamiento de los algoritmos y validaciones del backend:
```bash
python test_tpi.py
```
Resultado: **14 de 14 tests superados (100% OK)**.

---

## 📁 Contenido de este Paquete

```text
Defensa_TPI_Paises/
├── INICIAR_APP.bat             # Lanzador directo con 1 clic para Windows
├── app_web.py                  # Servidor HTTP nativo y API REST en Python
├── Documentacion_TPI.pdf       # Informe formal de entrega
├── GUIA_DEFENSA.md             # Guion de exposición y preguntas de examen
├── README.md                   # Este documento de referencia
├── test_tpi.py                 # Suite de 14 pruebas automatizadas
├── requirements.txt            # Dependencias del entorno
├── Procfile                    # Archivo de despliegue en la nube
├── render.yaml                 # Manifiesto de despliegue en Render
├── datos/                      # Datasets en CSV
├── modulos/                    # Módulos de lógica, archivos, ordenamiento y validación
└── frontend/                   # Interfaz web interactiva (HTML, CSS, JS)
```
