# 🎓 GUÍA COMPLETA PARA LA DEFENSA DEL TRABAJO PRÁCTICO INTEGRADOR (TPI)
**Cátedra:** Programación 1  
**Carrera:** Tecnicatura Universitaria en Programación a Distancia  
**Institución:** Universidad Tecnológica Nacional (UTN)  
**Proyecto:** Sistema de Gestión de Datos de Países  

---

## 📌 1. Resumen Ejecutivo del Proyecto

* **Objetivo:** Desarrollar una solución integral para la gestión, filtrado, ordenamiento algorítmico y cálculo estadístico sobre un dataset de países.
* **Paradigma:** Programación estructurada y modularizada (principio de responsabilidad única por función).
* **Tecnología del Núcleo:** **Python 3 puro (Standard Library)**. No requiere la instalación de ningún framework externo (sin Flask, sin Django, sin FastAPI, sin Pandas). Todo corre sobre módulos nativos: `http.server`, `socketserver`, `json`, `csv`, `unicodedata`, `urllib.parse` y `unittest`.
* **Presentación:** Interfaz visual moderna (SPA en HTML5, CSS3 y Vanilla JavaScript) servida por el backend nativo de Python, con persistencia en archivos CSV y validaciones integrales en el servidor.

---

## 🗂️ 2. Estructura de la Carpeta de Defensa

```text
Defensa_TPI_Paises/
├── INICIAR_APP.bat             # Lanzador rápido con doble clic para Windows
├── app_web.py                  # Servidor HTTP nativo en Python con API REST y validaciones
├── Documentacion_TPI.pdf       # Informe formal y académico completo de entrega
├── GUIA_DEFENSA.md             # Esta guía estratégica para exponer frente al profesor
├── README.md                   # Resumen del proyecto y especificaciones técnicas
├── test_tpi.py                 # Suite de 14 pruebas unitarias automatizadas (100% OK)
├── requirements.txt            # Especificación de dependencias (reportlab opcional)
├── Procfile                    # Configuración de despliegue en la nube
├── render.yaml                 # Manifiesto de despliegue para Render.com
├── datos/
│   ├── paises.csv              # Dataset base de prueba (25 países)
│   └── paises_mundo_completo.csv # Dataset mundial ampliado (60 países)
├── modulos/
│   ├── __init__.py             # Inicializador del paquete
│   ├── archivos.py             # Lectura y guardado de CSV con manejo de excepciones
│   ├── operaciones.py          # Altas, actualizaciones, búsquedas y filtros
│   ├── ordenamiento.py         # Bubble Sort nativo parametrizable (Ascendente / Descendente)
│   ├── estadisticas.py         # Promedios, extremos y distribución geográfica
│   └── validaciones.py         # Validaciones puras del Backend y reglas de negocio
└── frontend/                   # Interfaz de usuario interactiva (SPA)
    ├── index.html              # Estructura semántica, accesibilidad y modales nativos
    ├── styles.css              # Diseño responsivo y temas Claro / Oscuro
    └── app.js                  # Lógica del cliente, sincronización y llamadas a la API
```

---

## ⏱️ 3. Guion de Exposición Paso a Paso (5 a 8 Minutos)

### Paso 1: Introducción y Arquitectura (1 minuto)
* *"Buenas tardes, profesor. En este Trabajo Práctico Integrador desarrollamos un sistema modular en Python 3 para la administración y análisis de un dataset mundial de países."*
* *"Decidimos implementar una arquitectura cliente-servidor completa utilizando exclusivamente la biblioteca estándar de Python, sin frameworks externos como Flask o FastAPI. El backend expone una API REST nativa que atiende al frontend interactivo."*

### Paso 2: Estructura de Datos y Modelo de Dominio (1 minuto)
* *"El modelo de dominio representa cada país mediante un **diccionario** con 4 atributos tipados: `nombre` (string), `continente` (string), `poblacion` (entero positivo) y `superficie` (entero positivo en km²)."*
* *"En memoria, el conjunto completo de países se almacena en una **lista de diccionarios** (`list[dict]`). Elegimos esta estructura porque permite acceso directo y semántico a los atributos por clave (`pais['poblacion']`), simplifica las iteraciones en bucles `for` y se mapea de forma natural con los registros del archivo CSV."*

### Paso 3: Demostración en Vivo en Pantalla (2 a 3 minutos)
*(Abrir la aplicación haciendo doble clic en `INICIAR_APP.bat` o ejecutando `python app_web.py`)*

1. **Dashboard y KPIs:**
   * Mostrar las tarjetas superiores de estadísticas: Total de países, Mayor/Menor población y Promedios globales.
   * Mostrar el gráfico de barras interactivo con la distribución porcentual por continente.
2. **Búsqueda Flexible:**
   * Escribir en la barra de búsqueda `japon` o `ar` sin tildes para demostrar que el sistema normaliza acentos y mayúsculas (`unicodedata`).
   * Probar el checkbox de "Coincidencia exacta".
3. **Filtros Combinados:**
   * Filtrar por continente (ej. *América*).
   * Ingresar un rango de población (ej. mínimo 30.000.000 y máximo 150.000.000) o de superficie.
4. **Ordenamiento Algorítmico (Ascendente y Descendente):**
   * Usar los selectores del panel de filtros:
     * Ordenar por **Población** en sentido **Descendente** (muestra los más poblados primero).
     * Ordenar por **Superficie / Territorio** en sentido **Ascendente** (de menor a mayor extensión).
     * Ordenar por **Nombre** en sentido **Ascendente** (A-Z alfabético).
   * Mostrar que también se puede ordenar haciendo clic directamente en las cabeceras de la tabla (`País`, `Continente`, `Población`, `Superficie`).
5. **Validaciones en Acción (Alta y Edición):**
   * Abrir "Nuevo País":
     * Intentar ingresar un nombre con símbolos (ej. `País123$`) o población negativa (`-5000`): **El backend rechaza los datos y devuelve los mensajes de error correspondientes**.
     * Intentar ingresar un país ya existente (ej. `Argentina` o `argentina`): **El backend detecta duplicados y bloquea el alta**.
     * Ingresar un país válido (ej. `Uruguay`) para mostrar que se agrega exitosamente a la lista y actualiza los KPIs.
   * Hacer clic en "✏️ Editar" en cualquier fila para actualizar su población y superficie.
6. **Persistencia e Intercambio:**
   * Mostrar el botón "💾 Exportar CSV" para descargar los datos actualizados.
   * Mostrar la alternancia del botón "🌓" de Modo Oscuro / Modo Claro.

### Paso 4: Algoritmos y Backend (1 a 2 minutos)
* *"Para el ordenamiento programamos manualmente el algoritmo clásico **Bubble Sort (Burbuja)** en el módulo `ordenamiento.py`."*
* *"Le agregamos una optimización con bandera booleana (`hubo_intercambio`): si en una pasada no se realiza ningún swap, el algoritmo se detiene inmediatamente, logrando un mejor caso lineal $O(n)$ si los datos ya están ordenados."*
* *"En `validaciones.py` implementamos validaciones defensivas independientes del frontend. Si alguien realiza peticiones HTTP directas con datos corruptos o valores negativos, el backend los intercepta y devuelve respuestas HTTP 400 Bad Request."*

### Paso 5: Suite de Pruebas Unitarias (30 segundos)
* Abrir la terminal y ejecutar:
  ```bash
  python test_tpi.py
  ```
* Mostrar que los **14 tests unitarios** se ejecutan en milisegundos y pasan con resultado `OK` (pruebas de normalización, validaciones de alta/edición, filtros de rango y ordenamientos ascendentes/descendentes).

---

## ❓ 4. Preguntas Típicas del Profesor y Cómo Responder

### P1: ¿Qué librerías externas de terceros instalaron con `pip`?
> **Respuesta:** *"Para el funcionamiento de la aplicación **no usamos ninguna librería externa**. Todo el sistema (servidor HTTP, endpoints de la API, persistencia CSV, ordenamiento y tests unitarios) fue desarrollado con la **biblioteca estándar de Python** (`http.server`, `socketserver`, `csv`, `json`, `unicodedata`, `unittest`). La única librería de terceros utilizada en el repositorio fue `reportlab`, usada de forma auxiliar para compilar programáticamente el informe académico en PDF."*

---

### P2: ¿Por qué eligieron una lista de diccionarios en lugar de una matriz o tuplas?
> **Respuesta:** *"Una lista de tuplas nos obligaría a acceder a los atributos mediante índices numéricos (`pais[0]`, `pais[1]`), lo cual es propenso a errores si el orden de las columnas cambia y resta legibilidad al código. Una lista de diccionarios nos brinda **clave-valor semántica** (`pais['nombre']`, `pais['poblacion']`), lo que hace al código autodocumentado, fácil de serializar a formato JSON para el frontend y muy sencillo de convertir a filas de CSV."*

---

### P3: ¿Cómo funciona el algoritmo de ordenamiento y cuál es su complejidad algorítmica?
> **Respuesta:** *"Implementamos **Bubble Sort**. Compara elementos adyacentes y los intercambia si están en el orden incorrecto según el sentido elegido (ascendente o descendente).  
> Su complejidad temporal es:
> * **Peor caso y caso promedio:** $O(n^2)$, cuando la lista está invertida o desordenada.
> * **Mejor caso:** $O(n)$, gracias a la bandera de optimización `hubo_intercambio`, que corta la ejecución en la primera pasada si la lista ya está ordenada.  
> Su complejidad espacial es $O(1)$ adicional ya que opera por intercambio de referencias sin duplicar memoria innecesaria."*

---

### P4: ¿Por qué agregaron validaciones en el backend si el formulario HTML ya tiene validaciones?
> **Respuesta:** *"Por el principio de **seguridad y programación defensiva**. Las validaciones del frontend son solo para mejorar la experiencia de usuario (UX), pero nunca deben ser la única barrera de seguridad, ya que cualquier usuario avanzado o cliente HTTP (como Postman o cURL) puede enviar solicitudes directamente a la API saltándose el formulario web. El backend siempre debe validar tipos de datos, valores numéricos mayores a cero, coherencia de rangos (`min <= max`) y duplicados."*

---

### P5: ¿Cómo resolvieron el problema de las búsquedas con acentos o mayúsculas?
> **Respuesta:** *"Creamos la función `normalizar_texto` utilizando el módulo nativo `unicodedata`. Aplica una descomposición canónica (`NFD`), lo que separa las letras base de sus tildes diacríticas, y luego filtra cualquier carácter de categoría `'Mn'` (marcas sin espacio). De este modo, `'Japón'`, `'japon'` y `'JAPÓN'` se normalizan a `'japon'`, permitiendo comparaciones uniformes sin importar cómo lo escriba el usuario."*

---

### P6: ¿Cómo se comunica el frontend con Python si no usaron Flask ni Django?
> **Respuesta:** *"Heredamos de `http.server.SimpleHTTPRequestHandler`. Sobrescribimos los métodos `do_GET`, `do_POST` y `do_PUT` para interceptar las rutas que comienzan con `/api/`. Leemos el cuerpo JSON con `rfile.read()`, ejecutamos las funciones de nuestros módulos de Python (`operaciones.py`, `ordenamiento.py`, etc.) y respondemos con encabezados `application/json` y códigos de estado HTTP estándar (200, 201, 400, 404)."*

---

## 🚀 5. Checklist Rápido Previo a la Defensa

- [ ] Tener el archivo `Documentacion_TPI.pdf` abierto en una pestaña.
- [ ] Tener la carpeta `Defensa_TPI_Paises` abierta en el Explorador de Archivos.
- [ ] Ejecutar `INICIAR_APP.bat` y verificar que la web abre en `http://localhost:8000`.
- [ ] Tener una terminal lista para ejecutar `python test_tpi.py` y mostrar los 14 tests pasando.
- [ ] Recordar los nombres de los 4 módulos clave: `archivos.py`, `operaciones.py`, `ordenamiento.py` y `validaciones.py`.
